from tkinter import *
from tkinter import messagebox
turtle=" _____     ____\n /      \  |  o |\n|        |/ ___\|\n|_________/   \n|_|_| |_|_|"
window = Tk()

window.title("Specially for Michael")

window.geometry('500x500')
lbl2= Label(window, text="")
lbl= Label(window, text="Hi Michael,\n let's place some straws on sea turtles")
lbl3= Label(window, text=turtle)
lbl3.grid(column=3, row=4)
lbl2.grid(column=3, row=3)
lbl.grid(column=0, row=0)

def clicked():
    
    lbl2.configure(text="_______|")
    messagebox.showinfo("Success!","Wooooooow you successfully placed this straw on the sea turtle!!!")

btn = Button(window, text="Place a straw", command=clicked, bg="green", fg="white")

btn.grid(column=1, row=0)

window.mainloop()